from django.db import models

# Create your models here.
class Cadastro_usuario(models.Model):
    nome = models.CharField(max_length=30)
    sobrenome = models.CharField(max_length=30)
    sexo = models.CharField(max_length=1, choices=[('M', 'Masculino'), ('F', 'Feminino')], null=True)
    data_nascimento = models.DateTimeField(null=True, blank=True)
    email = models.EmailField (unique=True)
    senha = models.CharField(max_length=256) #default='8a9bdbc14553980660e7c9b109b23bc03aff95394a6b790a8f62d9573a7ea4dc') #juliana2211
    data_criacao = models.DateTimeField(auto_now_add=True)
    data_alteracao = models.DateTimeField(auto_now=True)

class Topico(models.Model): 
    assunto = models.CharField(max_length=100)
    autor = models.ForeignKey(Cadastro_usuario, on_delete=models.CASCADE)
    categoria = models.CharField(max_length=50)
    data_postagem = models.DateTimeField(auto_now_add=True)
    #imagem
    mensagens = models.CharField(max_length=500)

class Comentario(models.Model):
    topico = models.ForeignKey(Topico, on_delete=models.CASCADE)
    autor = models.ForeignKey(Cadastro_usuario, on_delete=models.CASCADE)
    conteudo = models.CharField(max_length=200)
    data_comentario = models.DateTimeField(auto_now_add=True)

from django.shortcuts import render, redirect, get_object_or_404
from .forms import Formulario_cadastro_usuario, Formulario_para_login
from .models import Cadastro_usuario

# Create your views here.

def teste_view(request):
    variavel = 'Juliana'
    return render(request, 'teste.html', {'variavelhtml':variavel})

def cadastrar_usuario_view(request):
    if request.method == 'POST':
        form = Formulario_cadastro_usuario(request.POST)
        if form.is_valid():
                usuario = form.save(commit=False)
                usuario.nome = form.cleaned_data['nome']
                usuario.sobrenome = form.cleaned_data['sobrenome']
                usuario.sexo = form.cleaned_data['sexo']
                usuario.data_nascimento = form.cleaned_data['data_nascimento']
                usuario.email = form.cleaned_data['email']
                usuario.senha = form.cleaned_data['senha']
                usuario.save()
        return redirect('teste')
    else:
        formulario_cadastro_usuario = Formulario_cadastro_usuario()
        return render(request, 'cadastro_usuario.html', {'form': formulario_cadastro_usuario})
    
def editar_usuario_view(request, user_id):
    usuario = get_object_or_404(Cadastro_usuario, pk=user_id)
    if request.method == 'POST':
        usuario.senha = request.POST['senha']
        form = Formulario_cadastro_usuario(request.POST, instance=usuario)
        if form.is_valid():
            form.save()
            return redirect('lista_topico')
    else:
        form = Formulario_cadastro_usuario(instance=usuario)

    return render(request, 'editar_usuario.html', {'form': form})

def login_view(request):
    
    if request.method == 'POST':
       form = Formulario_para_login(request.POST)
       email_digitado = request.POST['email']
       senha_digitada = request.POST['senha']
       if validar_login(email_digitado, senha_digitada):
           return redirect('lista_topico')
       else:
            formulario_para_login = Formulario_para_login()
            erro = "Login/Senha Invalido"
            return render(request, 'login.html', {'form': formulario_para_login, 'erro': erro})
    else:
        formulario_para_login = Formulario_para_login()
        return render(request, 'login.html', {'form': formulario_para_login})



def lista_topico_view(request):
    return render(request, 'lista_topico.html')



def validar_login(email, senha):
    return Cadastro_usuario.objects.filter(email=email, senha=criptografar_senha(senha)).exists()


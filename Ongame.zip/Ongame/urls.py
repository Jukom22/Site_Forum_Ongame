"""
URL configuration for Ongame project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from Forum import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('teste/', views.teste_view, name='teste'),
    path('cadastrar_usuario', views.cadastrar_usuario_view, name='cadastrar_usuario'),
    path('login', views.login_view, name='login'),
    path('lista_topico', views.lista_topico_view, name='lista_topico'),
    path('editar_usuario/<int:user_id>/', views.editar_usuario_view, name='editar_usuario'),
]
